<?php
session_start();
$koneksi = mysqli_connect('localhost','root','','ryuperpus');